-- The total number of order place
SELECT count(order_id) as Total_Orders
FROM orders
